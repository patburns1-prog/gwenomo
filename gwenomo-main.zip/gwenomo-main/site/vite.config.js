import { defineConfig } from 'vite';
import { resolve } from 'node:path';

export default defineConfig({
  build: {
    rollupOptions: {
      input: {
        main: resolve(__dirname, 'index.html'),
        catalogo: resolve(__dirname, 'catalogo/index.html'),
        personaliza: resolve(__dirname, 'personaliza/index.html'),
      },
    },
  },
});
